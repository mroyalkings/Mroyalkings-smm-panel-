export type Service = {
  id: string;
  name: string;
  category: string;
  rate: number; // price per 1000
  min: number;
  max: number;
  avgTime: string;
  quality: "Premium" | "Standard" | "Economy";
};

export type Order = {
  id: string;
  service: string;
  category: string;
  link: string;
  quantity: number;
  price: number;
  status: "Pending" | "In Progress" | "Completed" | "Partial";
  date: string;
};

export const categories = [
  "Instagram",
  "TikTok",
  "YouTube",
  "Twitter / X",
  "Facebook",
  "Telegram",
  "Spotify",
];

export const services: Service[] = [
  { id: "S1001", name: "Instagram Followers [Real][Speed: 10K/day]", category: "Instagram", rate: 1.20, min: 50, max: 100000, avgTime: "2h 15m", quality: "Premium" },
  { id: "S1002", name: "Instagram Likes [Instant]", category: "Instagram", rate: 0.45, min: 20, max: 50000, avgTime: "0h 12m", quality: "Premium" },
  { id: "S1003", name: "Instagram Story Views", category: "Instagram", rate: 0.15, min: 100, max: 200000, avgTime: "0h 05m", quality: "Standard" },
  { id: "S1004", name: "Instagram Reels Views [Fast]", category: "Instagram", rate: 0.08, min: 100, max: 1000000, avgTime: "0h 20m", quality: "Economy" },
  { id: "S2001", name: "TikTok Followers [HQ]", category: "TikTok", rate: 2.10, min: 50, max: 50000, avgTime: "1h 30m", quality: "Premium" },
  { id: "S2002", name: "TikTok Likes [Instant]", category: "TikTok", rate: 0.30, min: 20, max: 100000, avgTime: "0h 08m", quality: "Premium" },
  { id: "S2003", name: "TikTok Video Views", category: "TikTok", rate: 0.05, min: 100, max: 5000000, avgTime: "0h 03m", quality: "Economy" },
  { id: "S3001", name: "YouTube Subscribers [Real]", category: "YouTube", rate: 3.50, min: 50, max: 20000, avgTime: "6h 00m", quality: "Premium" },
  { id: "S3002", name: "YouTube Watchtime [4000h]", category: "YouTube", rate: 12.00, min: 1, max: 5000, avgTime: "72h", quality: "Premium" },
  { id: "S3003", name: "YouTube Views [Fast]", category: "YouTube", rate: 0.75, min: 500, max: 1000000, avgTime: "0h 30m", quality: "Standard" },
  { id: "S4001", name: "Twitter / X Followers", category: "Twitter / X", rate: 2.80, min: 50, max: 30000, avgTime: "3h 00m", quality: "Standard" },
  { id: "S4002", name: "Twitter / X Retweets", category: "Twitter / X", rate: 1.10, min: 20, max: 20000, avgTime: "1h 00m", quality: "Standard" },
  { id: "S5001", name: "Facebook Page Likes", category: "Facebook", rate: 1.90, min: 100, max: 50000, avgTime: "2h 00m", quality: "Standard" },
  { id: "S5002", name: "Facebook Post Reactions", category: "Facebook", rate: 0.60, min: 50, max: 30000, avgTime: "0h 45m", quality: "Economy" },
  { id: "S6001", name: "Telegram Channel Members", category: "Telegram", rate: 1.50, min: 100, max: 100000, avgTime: "1h 15m", quality: "Premium" },
  { id: "S6002", name: "Telegram Post Views", category: "Telegram", rate: 0.20, min: 100, max: 500000, avgTime: "0h 10m", quality: "Economy" },
  { id: "S7001", name: "Spotify Plays [Royalty]", category: "Spotify", rate: 0.90, min: 1000, max: 1000000, avgTime: "12h", quality: "Premium" },
  { id: "S7002", name: "Spotify Monthly Listeners", category: "Spotify", rate: 2.40, min: 500, max: 100000, avgTime: "24h", quality: "Premium" },
];

export const recentOrders: Order[] = [
  { id: "ORD-9841", service: "Instagram Followers [Real]", category: "Instagram", link: "https://instagram.com/royalbrand", quantity: 5000, price: 6.0, status: "Completed", date: "2025-01-14" },
  { id: "ORD-9837", service: "TikTok Video Views", category: "TikTok", link: "https://tiktok.com/@creator/video/123", quantity: 100000, price: 5.0, status: "In Progress", date: "2025-01-14" },
  { id: "ORD-9820", service: "YouTube Subscribers [Real]", category: "YouTube", link: "https://youtube.com/@channel", quantity: 1000, price: 3.5, status: "Partial", date: "2025-01-13" },
  { id: "ORD-9805", service: "Spotify Plays [Royalty]", category: "Spotify", link: "https://open.spotify.com/track/abc", quantity: 50000, price: 45.0, status: "Completed", date: "2025-01-13" },
  { id: "ORD-9790", service: "Telegram Channel Members", category: "Telegram", link: "https://t.me/royalchannel", quantity: 2000, price: 3.0, status: "Pending", date: "2025-01-12" },
  { id: "ORD-9778", service: "Instagram Likes [Instant]", category: "Instagram", link: "https://instagram.com/p/xyz", quantity: 10000, price: 4.5, status: "Completed", date: "2025-01-12" },
];