import { useState, useMemo } from "react";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { services, categories } from "@/data/services";
import { Search, Zap, ShieldCheck, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export function Services() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const filtered = useMemo(() => {
    return services.filter((s) => {
      const matchCat =
        activeCategory === "All" || s.category === activeCategory;
      const matchSearch =
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.id.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [search, activeCategory]);

  return (
    <div className="space-y-5">
      {/* Search + filter bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search services by name or ID..."
            className="border-slate-700 bg-slate-800/50 pl-9 text-slate-200 placeholder:text-slate-500"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {["All", ...categories].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                "rounded-full px-3 py-1.5 text-xs font-medium transition-all",
                activeCategory === cat
                  ? "bg-amber-500 text-slate-950"
                  : "bg-slate-700/50 text-slate-300 hover:bg-slate-700"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Service cards grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filtered.map((s) => (
          <Card
            key={s.id}
            className="group border-slate-700/50 bg-slate-800/40 transition-all hover:border-amber-500/30 hover:shadow-lg hover:shadow-amber-500/5"
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <span className="font-mono text-xs text-slate-500">
                    {s.id}
                  </span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "ml-2 border text-[10px] font-semibold",
                      s.quality === "Premium"
                        ? "border-amber-500/30 bg-amber-500/10 text-amber-400"
                        : s.quality === "Standard"
                        ? "border-sky-500/30 bg-sky-500/10 text-sky-400"
                        : "border-slate-600/30 bg-slate-600/10 text-slate-400"
                    )}
                  >
                    {s.quality}
                  </Badge>
                </div>
                <span className="rounded-md bg-slate-700/40 px-2 py-1 text-[10px] text-slate-400">
                  {s.category}
                </span>
              </div>

              <h3 className="mt-2 text-sm font-medium leading-snug text-slate-200 group-hover:text-white">
                {s.name}
              </h3>

              <div className="mt-4 flex items-center gap-4 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <Zap className="h-3.5 w-3.5 text-amber-400" />
                  {s.avgTime}
                </span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                  Refill
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5 text-sky-400" />
                  {s.min}–{s.max > 999999 ? "∞" : s.max.toLocaleString()}
                </span>
              </div>

              <div className="mt-4 flex items-end justify-between border-t border-slate-700/40 pt-3">
                <span className="text-xs text-slate-500">per 1,000</span>
                <span className="font-serif text-xl font-bold text-amber-400">
                  ${s.rate.toFixed(2)}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center">
          <Search className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm text-slate-500">
            No services match your search.
          </p>
        </div>
      )}
    </div>
  );
}