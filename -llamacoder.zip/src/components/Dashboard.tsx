import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Wallet,
  TrendingUp,
  Package,
  CheckCircle2,
  Clock,
  Activity,
} from "lucide-react";
import { recentOrders } from "@/data/services";
import { cn } from "@/lib/utils";

const statusStyles: Record<string, string> = {
  Completed: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  "In Progress": "bg-amber-500/15 text-amber-400 border-amber-500/30",
  Pending: "bg-sky-500/15 text-sky-400 border-sky-500/30",
  Partial: "bg-rose-500/15 text-rose-400 border-rose-500/30",
};

export function Dashboard() {
  const completed = recentOrders.filter((o) => o.status === "Completed").length;
  const totalOrders = recentOrders.length;
  const completionRate = Math.round((completed / totalOrders) * 100);

  const stats = [
    {
      label: "Account Balance",
      value: "$247.85",
      icon: Wallet,
      accent: "from-amber-400/20 to-amber-600/5",
      iconColor: "text-amber-400",
    },
    {
      label: "Total Orders",
      value: "1,284",
      icon: Package,
      accent: "from-sky-400/20 to-sky-600/5",
      iconColor: "text-sky-400",
    },
    {
      label: "Completed",
      value: "1,197",
      icon: CheckCircle2,
      accent: "from-emerald-400/20 to-emerald-600/5",
      iconColor: "text-emerald-400",
    },
    {
      label: "This Month",
      value: "$1,840",
      icon: TrendingUp,
      accent: "from-violet-400/20 to-violet-600/5",
      iconColor: "text-violet-400",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card
            key={s.label}
            className="relative overflow-hidden border-slate-700/50 bg-slate-800/40"
          >
            <div
              className={cn(
                "absolute inset-0 bg-gradient-to-br opacity-60",
                s.accent
              )}
            />
            <CardContent className="relative p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-400">{s.label}</p>
                  <p className="mt-1 font-serif text-2xl font-bold text-white">
                    {s.value}
                  </p>
                </div>
                <div
                  className={cn(
                    "rounded-xl bg-slate-900/50 p-2.5 ring-1 ring-white/10",
                    s.iconColor
                  )}
                >
                  <s.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Completion + activity */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="border-slate-700/50 bg-slate-800/40 lg:col-span-1">
          <CardHeader>
            <CardTitle className="font-serif text-lg text-white">
              Completion Rate
            </CardTitle>
            <CardDescription className="text-slate-400">
              Last 30 days performance
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-end justify-between">
              <span className="font-serif text-4xl font-bold text-amber-400">
                {completionRate}%
              </span>
              <span className="text-sm text-slate-400">
                {completed}/{totalOrders} orders
              </span>
            </div>
            <Progress value={completionRate} className="h-2.5 bg-slate-700" />
            <div className="flex items-center gap-2 pt-1 text-sm text-slate-400">
              <Activity className="h-4 w-4 text-amber-400" />
              <span>Avg. start time: 8 minutes</span>
            </div>
          </CardContent>
        </Card>

        {/* Recent orders */}
        <Card className="border-slate-700/50 bg-slate-800/40 lg:col-span-2">
          <CardHeader>
            <CardTitle className="font-serif text-lg text-white">
              Recent Orders
            </CardTitle>
            <CardDescription className="text-slate-400">
              Your latest campaign activity
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentOrders.slice(0, 5).map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between rounded-lg border border-slate-700/40 bg-slate-900/30 px-4 py-3 transition-colors hover:border-amber-500/30 hover:bg-slate-900/50"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono text-slate-500">
                        {order.id}
                      </span>
                      <Badge
                        variant="outline"
                        className={cn(
                          "border text-[10px] font-medium",
                          statusStyles[order.status]
                        )}
                      >
                        {order.status}
                      </Badge>
                    </div>
                    <p className="mt-1 truncate text-sm font-medium text-slate-200">
                      {order.service}
                    </p>
                    <p className="text-xs text-slate-500">
                      {order.quantity.toLocaleString()} units · ${order.price.toFixed(2)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Clock className="h-3.5 w-3.5" />
                    {order.date}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}