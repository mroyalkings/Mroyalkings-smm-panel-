import { useState, useMemo } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { services, categories, type Service } from "@/data/services";
import { Search, Link2, Calculator, Sparkles, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function NewOrder() {
  const [selectedCategory, setSelectedCategory] = useState<string>("Instagram");
  const [selectedServiceId, setSelectedServiceId] = useState<string>("");
  const [link, setLink] = useState("");
  const [quantity, setQuantity] = useState<string>("");
  const [search, setSearch] = useState("");

  const filteredServices = useMemo(() => {
    return services.filter(
      (s) =>
        s.category === selectedCategory &&
        (s.name.toLowerCase().includes(search.toLowerCase()) ||
          s.id.toLowerCase().includes(search.toLowerCase()))
    );
  }, [selectedCategory, search]);

  const selectedService: Service | undefined = services.find(
    (s) => s.id === selectedServiceId
  );

  const qty = parseInt(quantity) || 0;
  const price = selectedService
    ? (qty / 1000) * selectedService.rate
    : 0;

  const canSubmit =
    selectedService &&
    link.trim().length > 0 &&
    qty >= selectedService.min &&
    qty <= selectedService.max;

  const handleSubmit = () => {
    if (!canSubmit) return;
    toast.success("Order placed successfully!", {
      description: `${selectedService!.name} — ${qty.toLocaleString()} units for $${price.toFixed(2)}`,
    });
    setSelectedServiceId("");
    setLink("");
    setQuantity("");
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      {/* Service selection */}
      <Card className="border-slate-700/50 bg-slate-800/40 lg:col-span-3">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-white">
            Select a Service
          </CardTitle>
          <CardDescription className="text-slate-400">
            Choose from our premium catalog of social media services
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Category pills */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  setSelectedServiceId("");
                }}
                className={cn(
                  "rounded-full px-3.5 py-1.5 text-xs font-medium transition-all",
                  selectedCategory === cat
                    ? "bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20"
                    : "bg-slate-700/50 text-slate-300 hover:bg-slate-700"
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search services..."
              className="border-slate-700 bg-slate-900/50 pl-9 text-slate-200 placeholder:text-slate-500"
            />
          </div>

          {/* Service list */}
          <div className="max-h-80 space-y-2 overflow-y-auto pr-1">
            {filteredServices.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">
                No services found in this category.
              </div>
            ) : (
              filteredServices.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedServiceId(s.id)}
                  className={cn(
                    "flex w-full items-center justify-between rounded-xl border p-3.5 text-left transition-all",
                    selectedServiceId === s.id
                      ? "border-amber-500/50 bg-amber-500/10 ring-1 ring-amber-500/30"
                      : "border-slate-700/40 bg-slate-900/30 hover:border-slate-600 hover:bg-slate-900/50"
                  )}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-500">
                        {s.id}
                      </span>
                      <span
                        className={cn(
                          "rounded px-1.5 py-0.5 text-[10px] font-semibold",
                          s.quality === "Premium"
                            ? "bg-amber-500/20 text-amber-400"
                            : s.quality === "Standard"
                            ? "bg-sky-500/20 text-sky-400"
                            : "bg-slate-600/30 text-slate-400"
                        )}
                      >
                        {s.quality}
                      </span>
                    </div>
                    <p className="mt-1 truncate text-sm font-medium text-slate-200">
                      {s.name}
                    </p>
                    <p className="text-xs text-slate-500">
                      Min: {s.min.toLocaleString()} · Max: {s.max.toLocaleString()} · Avg: {s.avgTime}
                    </p>
                  </div>
                  <div className="ml-3 text-right">
                    <p className="font-serif text-lg font-bold text-amber-400">
                      ${s.rate.toFixed(2)}
                    </p>
                    <p className="text-[10px] text-slate-500">per 1K</p>
                  </div>
                </button>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Order form */}
      <Card className="border-slate-700/50 bg-slate-800/40 lg:col-span-2">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-white">
            Order Details
          </CardTitle>
          <CardDescription className="text-slate-400">
            Enter your link and quantity
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Selected service summary */}
          {selectedService ? (
            <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
              <div className="flex items-center gap-2 text-xs text-amber-400">
                <Sparkles className="h-3.5 w-3.5" />
                Selected Service
              </div>
              <p className="mt-1.5 text-sm font-medium text-slate-200">
                {selectedService.name}
              </p>
              <p className="text-xs text-slate-500">
                {selectedService.id} · ${selectedService.rate.toFixed(2)}/1K
              </p>
            </div>
          ) : (
            <div className="flex items-center gap-2 rounded-xl border border-slate-700/40 bg-slate-900/30 p-4 text-sm text-slate-500">
              <AlertCircle className="h-4 w-4" />
              Select a service to continue
            </div>
          )}

          {/* Link */}
          <div className="space-y-2">
            <Label className="text-slate-300">Link / URL</Label>
            <div className="relative">
              <Link2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <Input
                value={link}
                onChange={(e) => setLink(e.target.value)}
                placeholder="https://instagram.com/yourprofile"
                className="border-slate-700 bg-slate-900/50 pl-9 text-slate-200 placeholder:text-slate-500"
              />
            </div>
          </div>

          {/* Quantity */}
          <div className="space-y-2">
            <Label className="text-slate-300">Quantity</Label>
            <Input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder={
                selectedService
                  ? `Min: ${selectedService.min} — Max: ${selectedService.max}`
                  : "Enter quantity"
              }
              className="border-slate-700 bg-slate-900/50 text-slate-200 placeholder:text-slate-500"
            />
            {selectedService && qty > 0 && qty < selectedService.min && (
              <p className="text-xs text-rose-400">
                Minimum order is {selectedService.min.toLocaleString()}
              </p>
            )}
            {selectedService && qty > selectedService.max && (
              <p className="text-xs text-rose-400">
                Maximum order is {selectedService.max.toLocaleString()}
              </p>
            )}
          </div>

          {/* Quick quantity buttons */}
          {selectedService && (
            <div className="flex gap-2">
              {[selectedService.min, 1000, 5000, 10000].map((q) => (
                <button
                  key={q}
                  onClick={() => setQuantity(String(q))}
                  className="flex-1 rounded-lg border border-slate-700/50 bg-slate-900/30 py-1.5 text-xs text-slate-400 transition-colors hover:border-amber-500/30 hover:text-amber-400"
                >
                  {q.toLocaleString()}
                </button>
              ))}
            </div>
          )}

          {/* Price calc */}
          <div className="rounded-xl border border-slate-700/40 bg-slate-900/40 p-4">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Calculator className="h-3.5 w-3.5" />
              Price Breakdown
            </div>
            <div className="mt-3 flex items-center justify-between text-sm">
              <span className="text-slate-400">Quantity</span>
              <span className="font-medium text-slate-200">
                {qty.toLocaleString() || "—"}
              </span>
            </div>
            <div className="mt-1.5 flex items-center justify-between text-sm">
              <span className="text-slate-400">Rate / 1K</span>
              <span className="font-medium text-slate-200">
                {selectedService ? `$${selectedService.rate.toFixed(2)}` : "—"}
              </span>
            </div>
            <div className="my-3 h-px bg-slate-700/50" />
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-300">Total</span>
              <span className="font-serif text-2xl font-bold text-amber-400">
                ${price.toFixed(2)}
              </span>
            </div>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className="w-full bg-gradient-to-r from-amber-400 to-amber-600 text-base font-semibold text-slate-950 shadow-lg shadow-amber-500/20 hover:from-amber-300 hover:to-amber-500 disabled:opacity-40"
          >
            Place Order
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}