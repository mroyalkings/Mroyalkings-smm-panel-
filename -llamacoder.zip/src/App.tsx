import { useState } from "react";
import { Dashboard } from "@/components/Dashboard";
import { NewOrder } from "@/components/NewOrder";
import { Services } from "@/components/Services";
import { Crown, LayoutDashboard, PlusCircle, Layers, Wallet } from "lucide-react";
import { cn } from "@/lib/utils";
import { Toaster } from "sonner";

type Tab = "dashboard" | "new-order" | "services";

const tabs: { id: Tab; label: string; icon: typeof Crown }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "new-order", label: "New Order", icon: PlusCircle },
  { id: "services", label: "Services", icon: Layers },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <Toaster
        position="top-right"
        theme="dark"
        toastOptions={{
          style: {
            background: "rgb(30 41 59)",
            border: "1px solid rgb(71 85 105 / 0.5)",
            color: "rgb(226 232 240)",
          },
        }}
      />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-800/60 bg-slate-950/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 rounded-xl bg-amber-500/30 blur-md" />
              <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300 to-amber-600 shadow-lg shadow-amber-500/20">
                <Crown className="h-5 w-5 text-slate-950" />
              </div>
            </div>
            <div>
              <h1 className="font-serif text-xl font-bold leading-none text-white">
                m.<span className="text-amber-400">royalkings</span>
              </h1>
              <p className="mt-0.5 text-[10px] uppercase tracking-widest text-slate-500">
                SMM Panel
              </p>
            </div>
          </div>

          {/* Balance + user */}
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 px-3.5 py-2 sm:flex">
              <Wallet className="h-4 w-4 text-amber-400" />
              <span className="text-sm font-semibold text-amber-400">$247.85</span>
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-slate-700 to-slate-800 text-sm font-bold text-amber-400 ring-1 ring-white/10">
              RK
            </div>
          </div>
        </div>

        {/* Tab nav */}
        <nav className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="flex gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "relative flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors",
                  activeTab === tab.id
                    ? "text-amber-400"
                    : "text-slate-400 hover:text-slate-200"
                )}
              >
                <tab.icon className="h-4 w-4" />
                {tab.label}
                {activeTab === tab.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-600" />
                )}
              </button>
            ))}
          </div>
        </nav>
      </header>

      {/* Main content */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        {activeTab === "dashboard" && <Dashboard />}
        {activeTab === "new-order" && <NewOrder />}
        {activeTab === "services" && <Services />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/60 bg-slate-950">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
          <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
            <p className="text-xs text-slate-500">
              © 2025 m.royalkings — Premium SMM Services
            </p>
            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                All systems operational
              </span>
              <span>API v2.4</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}